package com.ssafy.sample.model.dao;

import java.sql.SQLException;
import java.util.List;

import com.ssafy.sample.dto.Movie;

public class MoviedaoImpl implements MovieDao {

	@Override
	public List<Movie> selectAll() throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Movie selectByCode(String code) throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int insert(Movie product) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteByCode(String code) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int update(Movie product) throws SQLException {
		// TODO Auto-generated method stub
		return 0;
	}

}
